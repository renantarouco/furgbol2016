For Debian Systems (Debian, Unbuntu, Knoppix, ...)
--------------------------------------------------

As root install compiler and libraries:
# apt-get install libprotobuf-dev protobuf-compiler libgtkmm-2.4-dev make g++

As normal user compile:
$ make
